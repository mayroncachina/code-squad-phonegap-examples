Exemplo de uso do Phonegap Build
==================

Exemplo de uso das APIs:
 * Pushwoosh - OK
 * Social Shared - OK
 * Barcodescan - OK
 * Goole Navigator - OK


 Phonegap Build: http://build.phonegap.com
